@extends('blog.master')
@section('title') About @endsection
@section('content')
    <h1 class="">I'm About</h1>
    @endsection
