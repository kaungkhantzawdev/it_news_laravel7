<?php


namespace App;


class Base
{

    public static $name = "IT News";
    public static $logo = "logos/logo.svg";
    public static $description  = "mmsit web dev project";

}
