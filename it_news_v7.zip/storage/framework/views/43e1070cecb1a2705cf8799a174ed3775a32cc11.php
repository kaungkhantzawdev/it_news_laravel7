<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH C:\Users\RiO\Desktop\it_news_v7\resources\views/components/menu-title.blade.php ENDPATH**/ ?>