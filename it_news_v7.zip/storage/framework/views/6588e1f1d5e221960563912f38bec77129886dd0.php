<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent("title","Admin Dashboard"); ?></title>
    <link rel="icon" href="<?php echo e(asset('logos/fav.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/app.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("dashboard/vendor/feather-icons-web/feather.css")); ?>">
    <?php echo $__env->yieldContent("head"); ?>
</head>
<body>
<?php if(auth()->guard()->guest()): ?>
    <?php echo $__env->yieldContent("content"); ?>
<?php else: ?>
    <section class="main container-fluid">
        <div class="row">
            <!--        sidebar start-->
        <?php echo $__env->make("layouts.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--        sidebar end-->
            <div class="col-12 col-lg-9 col-xl-10 vh-100 py-3 content">
            <?php echo $__env->make("layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--content Area Start-->
            <?php echo $__env->yieldContent("content"); ?>
            <!--content Area Start-->
            </div>
        </div>
    </section>
<?php endif; ?>
<script src="<?php echo e(asset("js/app.js")); ?>"></script>
<?php echo $__env->yieldContent("foot"); ?>

<?php if(auth()->guard()->check()): ?>
    <?php if(empty(Auth::user()->phone && Auth::user()->email)): ?>
    <?php echo $__env->make('user-profile.update-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php echo $__env->make('layouts.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\RiO\Desktop\it_news_v7\resources\views/layouts/app.blade.php ENDPATH**/ ?>