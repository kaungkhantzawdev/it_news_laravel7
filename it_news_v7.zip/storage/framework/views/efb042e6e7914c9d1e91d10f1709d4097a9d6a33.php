<li class="menu-item">
    <a href="<?php echo e($link); ?>" class="menu-item-link text-capitalize <?php echo e(Request::url() == $link? 'active': ''); ?>">
        <span>
            <i class="<?php echo e($class); ?>"></i>
            <?php echo e($name); ?>

        </span>
        <?php if($counter > 0): ?>
        <span class="badge badge-pill bg-white shadow-sm text-primary"><?php echo e($counter); ?></span>
            <?php endif; ?>
    </a>
</li>
<?php /**PATH C:\Users\RiO\Desktop\blog-v7-dashboard\resources\views\components\menu-item.blade.php ENDPATH**/ ?>