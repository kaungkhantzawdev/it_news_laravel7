<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH C:\Users\RiO\Desktop\blog-v7-dashboard\resources\views\components\menu-title.blade.php ENDPATH**/ ?>