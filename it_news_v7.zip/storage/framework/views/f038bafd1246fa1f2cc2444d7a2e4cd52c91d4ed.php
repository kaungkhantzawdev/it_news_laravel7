<div class="">
    <table class="table mb-0 table-hover table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th>Title</th>
            <th>Owner</th>
            <th>Control</th>
            <th>Created at</th>
            <th>Updated at</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = \App\Category::with("getUser")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->id); ?></td>
                <td><?php echo e($category->title); ?></td>
                <td><?php echo e($category->getUser->name); ?></td>
                <td>
                    <a href="<?php echo e(route('category.edit',$category->id)); ?>" class="btn btn-sm btn-primary">edit</a>
                    <form action="<?php echo e(route('category.destroy', $category->id)); ?>" class="d-inline-block" id="form<?php echo e($category->id); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="button" class="btn btn-sm btn-danger" onclick="return showAlert(<?php echo e($category->id); ?>)">delete</button>
                    </form>
                </td>
                <td>
                    <small>
                        <i class="feather-calendar"></i>
                        <?php echo e($category->created_at->format('d M Y')); ?>

                    </small>
                    <br>
                    <small>
                        <i class="feather-clock"></i>
                        <?php echo e($category->created_at->format('h:i A')); ?>

                    </small>
                </td>
                <td>
                    <small>
                        <i class="feather-calendar"></i>
                        <?php echo e($category->updated_at->format('d M Y')); ?>

                    </small>
                    <br>
                    <small>
                        <i class="feather-clock"></i>
                        <?php echo e($category->updated_at->format('h:i A')); ?>

                    </small>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->startSection('foot'); ?>
    <script>
        function showAlert(id) {
            Swal.fire({
                title: 'Are you sure <br> to delete this category?',
                text: "Really Sure",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Deleted',
                        'This Category is deleted',
                        'success'
                    );
                    setTimeout(function () {
                        $("#form"+id).submit();
                    }, 1500)
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\RiO\Desktop\blog-v7-dashboard\resources\views\category\list.blade.php ENDPATH**/ ?>