<?php if(session('toast')): ?>
    <script>
        let data = <?php echo json_encode(session('toast'), 15, 512) ?>;

        const Toast = Swal.mixin({
            toast: true,
            position: 'bottom-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: data.icon,
            title: data.title
        })

    </script>
<?php endif; ?>
<?php /**PATH C:\Users\RiO\Desktop\it_news_v7\resources\views/layouts/toast.blade.php ENDPATH**/ ?>