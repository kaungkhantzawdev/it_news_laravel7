<?php $__env->startSection('title'); ?> Article Detail  <?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
    <style>
        .description{
            white-space: pre-line;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginal30091868428b09767320233ef70f89faadea10d9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BreadCrumb::class, []); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('article.index')); ?>">Articles</a></li>
        <li class="breadcrumb-item active" aria-current="page">Article Detail</li>
     <?php if (isset($__componentOriginal30091868428b09767320233ef70f89faadea10d9)): ?>
<?php $component = $__componentOriginal30091868428b09767320233ef70f89faadea10d9; ?>
<?php unset($__componentOriginal30091868428b09767320233ef70f89faadea10d9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <div class="row">
        <div class="col-12 col-lg-8">
            <div class="">
                <div class="card border-0">
                    <div class="card-body">
                        <div class="">
                            <h4 class="mb-0">
                                <?php echo e($article->title); ?>

                            </h4>
                            <div class="mt-3">
                                <small class="mr-2">
                                    <i class="feather-user"></i>
                                    <?php echo e($article->getUser->name); ?>

                                </small>
                                <small class="mr-2">
                                    <i class="feather-calendar"></i>
                                    <?php echo e($article->created_at->format('d M Y')); ?>

                                </small>
                                <small class="mr-2">
                                    <i class="feather-clock"></i>
                                    <?php echo e($article->created_at->format('h:i A')); ?>

                                </small>
                            </div>
                        </div>
                        <div class="">
                            <p class="description text-black-50">
                                <?php echo e($article->description); ?>

                            </p>
                        </div>
                        <hr>
                       <div class="d-flex align-items-center justify-content-between">
                           <div class="">
                               <a href="<?php echo e(route('article.index')); ?>" class="btn btn-primary btn-sm">articles list</a>
                               <a href="<?php echo e(route('article.edit',$article->id)); ?>" class="btn btn-sm btn-warning">edit</a>
                               <form action="<?php echo e(route('article.destroy', $article->id)); ?>" class="d-inline-block" id="articleForm<?php echo e($article->id); ?>" method="post">
                                   <?php echo csrf_field(); ?>
                                   <?php echo method_field('delete'); ?>
                                   <button type="button" class="btn btn-sm btn-danger" onclick="return showAlert(<?php echo e($article->id); ?>)">delete</button>
                               </form>
                           </div>
                           <p class="mb-0">
                               <?php echo e($article->created_at->diffForHumans()); ?>

                           </p>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
    <script>
        function showAlert(id) {
            Swal.fire({
                title: 'Are you sure <br> to delete this category?',
                text: "Really Sure",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Deleted',
                        'This Category is deleted',
                        'success'
                    );
                    setTimeout(function () {
                        $("#articleForm"+id).submit();
                    }, 1500)
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RiO\Desktop\blog-v7-dashboard\resources\views/article/show.blade.php ENDPATH**/ ?>