<?php $__env->startSection('title'); ?> User Manager <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginal30091868428b09767320233ef70f89faadea10d9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BreadCrumb::class, []); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item active" aria-current="page">user manager</li>
     <?php if (isset($__componentOriginal30091868428b09767320233ef70f89faadea10d9)): ?>
<?php $component = $__componentOriginal30091868428b09767320233ef70f89faadea10d9; ?>
<?php unset($__componentOriginal30091868428b09767320233ef70f89faadea10d9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    <div class="row">
        <div class="col-12">
            <div class="">
                <div class="card border-0">
                    <div class="card-body">
                        <h4 class="mb-3">
                            <i class="feather-users mr-2"></i>
                            User List
                        </h4>
                        <table class="table table-bordered mb-0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Control</th>
                                <th>Created at</th>
                                <th>Updated at</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role); ?></td>
                                    <td class="text-nowrap">
                                        <?php if($user->role != 0): ?>
                                            <form action="<?php echo e(route('user-manager.makeAdmin')); ?>" class="d-inline-block" id="form<?php echo e($user->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" class="" name="id" value="<?php echo e($user->id); ?>">
                                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="return showAlert(<?php echo e($user->id); ?>)">make admin</button>
                                            </form>
                                            <button class="btn btn-sm btn-outline-warning" onclick="changePassword(<?php echo e($user->id); ?>,'<?php echo e($user->name); ?>')">change password</button>
                                            <?php if($user->isBaned == 0): ?>
                                                <form action="<?php echo e(route('user-manager.banUser')); ?>" class="d-inline-block" id="banForm<?php echo e($user->id); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" class="" name="id" value="<?php echo e($user->id); ?>">
                                                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="return banUser(<?php echo e($user->id); ?>)">banned</button>
                                                </form>
                                            <?php else: ?>
                                                <span>banned</span>
                                                <form action="<?php echo e(route('user-manager.unBanUser')); ?>" class="d-inline-block" id="unBanForm<?php echo e($user->id); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" class="" name="id" value="<?php echo e($user->id); ?>">
                                                    <button type="button" class="btn btn-sm btn-outline-success" onclick="return unBanUser(<?php echo e($user->id); ?>)">restore</button>
                                                </form>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span>admin</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <i class="feather-calendar"></i>
                                        <span>
                                            <?php echo e($user->created_at->format("d M Y")); ?>

                                        </span>
                                        <br>
                                        <i class="feather-clock"></i>
                                        <span>
                                            <?php echo e($user->created_at->format("h:i a")); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <i class="feather-calendar"></i>
                                        <span>
                                            <?php echo e($user->updated_at->format("d M Y")); ?>

                                        </span>
                                        <br>
                                        <i class="feather-clock"></i>
                                        <span>
                                            <?php echo e($user->updated_at->format("h:i a")); ?>

                                        </span>
                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="mt-3">
                            <?php echo e($users->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
    <script>
        function showAlert(id) {
            Swal.fire({
                title: 'Are you sure <br> to upgrade role?',
                text: "role ချိန်လိုက်ရင် admin လုပ်ပိုင်ခွင့်များကို ရရှိမှာဖြစ်ပါတယ်။",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Role Updated',
                        'အကောင့်မြှင်တင်ချင်း အောင်မြင်ပါသည်။',
                        'success'
                    );
                    setTimeout(function () {
                        $("#form"+id).submit();
                    }, 1500)
                }
            })
        }

        function banUser(id) {
            Swal.fire({
                title: 'Are you sure <br> to ban this user?',
                text: "Banned User",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Success Banned',
                        'Banned user',
                        'success'
                    );
                    setTimeout(function () {
                        $("#banForm"+id).submit();
                    }, 1500)
                }
            })
        }

        function unBanUser(id) {
            Swal.fire({
                title: 'Are you sure <br> to restore this user?',
                text: "Restored User",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Confirm'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(
                        'Success restore this user',
                        'normal user',
                        'success'
                    );
                    setTimeout(function () {
                        $("#unBanForm"+id).submit();
                    }, 1500)
                }
            })
        }

        let url = "<?php echo e(route('user-manager.changePassword')); ?>";
        function changePassword(id,name) {
            Swal.fire({
                title: 'Change Password for '+name,
                input: 'password',
                inputAttributes: {
                    autocapitalize: 'off',
                    required: "required",
                    minLength: 8
                },
                showCancelButton: true,
                confirmButtonText: 'change',
                showLoaderOnConfirm: true,
                preConfirm: function (newPassword) {
                    // console.log(id, newPassword)
                    $.post(url, {
                        id: id,
                        password: newPassword,
                        _token: "<?php echo e(csrf_token()); ?>"
                    }).done(function (data) {
                        if(data.status == 200){
                            Swal.fire({
                                icon: "success",
                                title: "Changed password",
                                text: data.message,
                            })
                        }else if(data.status == 422){
                            console.log(data)
                            Swal.fire({
                                icon:"error",
                                title:"Try again",
                                text: data.message.password[0]
                            });
                        }
                    })
                }
            })
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RiO\Desktop\blog-v7-dashboard\resources\views/user-manager/index.blade.php ENDPATH**/ ?>