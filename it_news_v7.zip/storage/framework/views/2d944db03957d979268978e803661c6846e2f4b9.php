<?php $__env->startSection('title'); ?> About <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="">I'm About</h1>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('blog.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\RiO\Desktop\blog-v7-dashboard\resources\views/blog/about.blade.php ENDPATH**/ ?>