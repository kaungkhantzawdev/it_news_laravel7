<div class="col-12 col-lg-3 col-xl-2 vh-100 sidebar">
    <div class="d-flex justify-content-between align-items-center py-2 mt-3">
        <div class="d-flex align-items-center">
            <img src="<?php echo e(asset(\App\Base::$logo)); ?>" class="w-50" alt="">
        </div>
        <button class="hide-sidebar-btn btn btn-light d-block d-lg-none">
            <i class="feather-x text-primary" style="font-size: 2em;"></i>
        </button>
    </div>
    <div class="nav-menu">
        <ul>
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('home')).'','class' => 'feather-home','name' => 'Home']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('index')).'','class' => 'feather-message-circle','name' => 'Go to News']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'articles manager']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('article.index')).'','class' => 'feather-list','name' => 'article list']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('article.create')).'','class' => 'feather-plus-circle','name' => 'create article']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

            <?php if(Auth::user()->role == 0): ?>
             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'user manager']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('user-manager.index')).'','class' => 'feather-users','name' => 'users']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php endif; ?>
             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'category manager']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('category.index')).'','class' => 'feather-layers','name' => 'category manager']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'user profile']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('profile')).'','class' => 'feather-user','name' => 'your profile']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('profile.update-photo')).'','class' => 'feather-image','name' => 'Update Photo']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('profile.update-nameEmail')).'','class' => 'feather-message-square','name' => 'Update info']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['link' => ''.e(route('profile.change-password-show')).'','class' => 'feather-refresh-ccw','name' => 'change password']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <li class="menu-item">
                <a class="btn btn-danger w-100" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();
                       document.getElementById('logout-form').submit();">
                     <span>
                    <i class="feather-log-out"></i>
                    Log out
                </span>
                </a>
            </li>


            

































































































        </ul>
    </div>
</div>
<?php /**PATH C:\Users\RiO\Desktop\blog-v7-dashboard\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>